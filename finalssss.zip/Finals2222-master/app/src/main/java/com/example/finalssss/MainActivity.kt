package com.example.finalssss

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)




        var enteremail = findViewById<EditText>(R.id.enteremail)
        var enterpassword = findViewById<EditText>(R.id.enterepassword)
        var continuebutton = findViewById<Button>(R.id.continuebutton)
        var signupbutton = findViewById<Button>(R.id.signupbutton);



        continuebutton.setOnClickListener {
            if(enteremail.text.isEmpty() || enterpassword.text.isEmpty()){
                Toast.makeText(this, "Field Is Empty", Toast.LENGTH_SHORT)

            } else{ var intent = Intent(this, firstpage_activity::class.java)
                startActivity(intent)
            }
        }
        signupbutton.setOnClickListener { var intent = Intent(this, signup_activity::class.java)
            startActivity(intent) }
        }
    }
