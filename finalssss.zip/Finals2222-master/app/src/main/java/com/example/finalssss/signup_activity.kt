package com.example.finalssss

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class signup_activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        var enteremail2 = findViewById<EditText>(R.id.enteremail2)
        var enterpassword2 = findViewById<EditText>(R.id.enterpassword2)
        var confirmpassword = findViewById<EditText>(R.id.confirmpassword)
        var gobackbtton = findViewById<Button>(R.id.gobackbutton)
        var continuebutton2 = findViewById<Button>(R.id.continuebutton2)


        continuebutton2.setOnClickListener {
            if (enteremail2.text.isEmpty() || enterpassword2.text.isEmpty() || confirmpassword.text.isEmpty()){
                Toast.makeText(this, "Field Is Empty", Toast.LENGTH_SHORT)
            } else if(enteremail2.text != enterpassword2.text){
                Toast.makeText(this, "Passwords Doesn't Match", Toast.LENGTH_SHORT)
            } else{ var intent = Intent(this, firstpage_activity::class.java)
                startActivity(intent)
            }



        }







    }
}