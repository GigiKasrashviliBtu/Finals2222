package com.example.finalssss

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class signup_activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
    }
}